import os

from flask import Flask

app = Flask(__name__)

from google.cloud import discoveryengine_v1beta
from google.oauth2 import service_account
import json
from google.protobuf.json_format import MessageToJson

from google.cloud import bigquery
from vertexai.preview.language_models import ChatModel, InputOutputTextPair, ChatMessage 
from flask import request
from vertexai.language_models import TextGenerationModel

SEARCH_CONFIG = "projects/488083062959/locations/global/collections/default_collection/dataStores/govil-gcp-search_1695030772657/servingConfigs/default_search"
QUESTION_CONTEXT = ":תנסח בקצרה את השאלה הבאה עד 10 מילים ותתיחס להיסטוריה של השיחה כדי להשלים תוכן לא מפורט, השאלה היא"
BOT_CONTEXT = "אתה עוזר וירטואלי של gov.il, אתה צריך להתבסס על המידע בהודעה המצורפת מטה, ולענות רק בנושאים שקשורים לשירותי ממשלה, תמיד תענה בצורה מנומסת" + " דוגמה: איזה מיסים צריך לשלם כשקונים דירה חדשה? הנה קישור לדף המבוקש "
LINK_TITLE = "למעבר למידע באתר לחץ"
INPUT_TEXT_EXAMPLE = "איך נרשמים אליה"
OUTPUT_TEXT_EXAMPLE = "איך נרשמים לתוכנית הוראה"

def chat_history(conversation_name):

    client = bigquery.Client()
    query = """
select author, content from (select JSON_VALUE(request,'$.queryInput.text.text') as author, JSON_VALUE(response,'$.queryResult.responseMessages[0].text.text[0]') as content 
FROM `chatbot_dev_big.dialogflow_bigquery_export_data`
where conversation_name = @conversation_name)  as a 
where content is not null and author is not null
limit 5
"""
    # Run the query  
    job_config = bigquery.QueryJobConfig(query_parameters = [bigquery.ScalarQueryParameter("conversation_name", "STRING", conversation_name)])

    query_job = client.query(query, job_config=job_config)

    # Get the results
    results = query_job.result()

    # Print the results
    messages = []
    for row in results: 
      messages.append(ChatMessage(author="user",content=row['author']))
      messages.append(ChatMessage(author="PaLM",content=row['content']))
    return messages
    
def chat_history_user_text(conversation_name):

    client = bigquery.Client()
    #limit is a parameter to change
    query = """
SELECT author, content
FROM (
  SELECT JSON_VALUE(request, '$.queryInput.text.text') AS author,
          JSON_VALUE(response, '$.queryResult.responseMessages[0].text.text[0]') AS content,
          ROW_NUMBER() OVER (ORDER BY NULL) AS row_number
  FROM `chatbot_dev_big.dialogflow_bigquery_export_data`
  WHERE conversation_name = @conversation_name) AS a
WHERE row_number > 1 and content is not null and author is not null
LIMIT 5
"""
    # Run the query  
    job_config = bigquery.QueryJobConfig(query_parameters = [bigquery.ScalarQueryParameter("conversation_name", "STRING", conversation_name)])
    query_job = client.query(query, job_config=job_config)

    # Get the results
    results = query_job.result()
    print(results)
    # Save the results
    messages = []
    for row in results: 
      messages.append(row['author'])
    m= '\n'.join(messages)
    return m

@app.route("/", methods=["POST"])
def dx_main():
    req = request.get_json()
    print(req)
    params = req['text']
    conversation_name=req['sessionInfo']['session']
    question = params
    prePalmRes = palm_pre_processing(question, conversation_name)
    summaraiz_conversation = palm_summaraiz_conversation(question,conversation_name)
    print("refined question")
    print(prePalmRes)
    #prePalmRes2 = palm_pre_processing2(question, conversation_name)
    #print(prePalmRes2)
    resJsonMin = dx_search(summaraiz_conversation) #question)
    palmRes = palm_processing(question, resJsonMin, conversation_name)
    if resJsonMin is not None:
        #messages = [{},{},{}]
        #messages[0] = {'text': { 'text': [resJsonMin['formattedUrl']]}}
        #messages[1] = {'text': { 'text': [resJsonMin['snippet']]}}
        #messages[2] = {'text': { 'text': [palmRes]}}
        messages = [{'text': { 'text': [palmRes]}},{ 
        "payload":{
            "richContent": [
                [
                {
                      
                    "type":"info",
                    "title": "",
                    "subtitle": "קישורים רלוונטיים",
                    "actionLink":" "
                
                },
                {
                    "type":"info",
                    "title": resJsonMin['title'],
                    "subtitle": " " ,
                    "actionLink":resJsonMin["formattedUrl"]
                }
                ]
            ]
            }
        }
        ]
    else:
        messages = [{'text': { 'text': ['']}}]  #messages = [{'text': { 'text': [palmRes]}}]

    print(messages)
    fullMsg={"sessionInfo": {}, "fulfillmentResponse":{"messages": messages}}
    msg=json.dumps(fullMsg)
    return(msg)


def dx_search(question):

    # Create a client    
    client = discoveryengine_v1beta.SearchServiceClient()
    print("DEBUG START question")
    print(question)
    print("DEBUG END question")


    # Initialize request argument(s)
    request = discoveryengine_v1beta.SearchRequest(
        serving_config=SEARCH_CONFIG,
        query=question
    )
    # Make the request
    page_result = client.search(request=request)

    # Handle the response
    for response in page_result:
        resJson = json.loads(MessageToJson(response._pb))
        resJsonMin = {
            'snippet': resJson['document']['derivedStructData']['snippets'][0]['snippet'],
            'formattedUrl': resJson['document']['derivedStructData']['link'],
            'title': resJson['document']['derivedStructData']['title']
        }
        print(resJsonMin)
        return(resJsonMin)

def palm_pre_processing(question, conversation_name):
    chat_model = ChatModel.from_pretrained("chat-bison@001")

    # TODO developer - override these parameters as needed:
    messages = chat_history(conversation_name)
    parameters = {
        "temperature": 0.5,  # Temperature controls the degree of randomness in token selection.
        "max_output_tokens": 256,  # Token limit determines the maximum amount of text output.
        "top_p": 0.5,  # Tokens are selected from most probable to least until the sum of their probabilities equals the top_p value.
        "top_k": 20,  # A top_k of 1 means the selected token is the most probable among all tokens.
    }
    context = QUESTION_CONTEXT + question
    
    chat = chat_model.start_chat(
        message_history=messages,
        context=context,
        examples=[
            InputOutputTextPair(
                input_text=INPUT_TEXT_EXAMPLE,
                output_text=OUTPUT_TEXT_EXAMPLE,
            )
        ]
    )

    response = chat.send_message(
        question, **parameters
    )
    return(response.text)

def palm_processing(question, resJsonMin, conversation_name):
    chat_model = ChatModel.from_pretrained("chat-bison@001")

    # TODO developer - override these parameters as needed:
    messages = chat_history(conversation_name)
    print("DEBUG START")
    print(messages)
    print("DEBUG END")
    print("DEBUG START2")
    print(resJsonMin)
    print("DEBUG END2")    
    parameters = {
        "temperature": 0.5,  # Temperature controls the degree of randomness in token selection.
        "max_output_tokens": 256,  # Token limit determines the maximum amount of text output.
        "top_p": 0.5,  # Tokens are selected from most probable to least until the sum of their probabilities equals the top_p value.
        "top_k": 20,  # A top_k of 1 means the selected token is the most probable among all tokens.
    }
    context = BOT_CONTEXT
    
    if resJsonMin is not None: 
        context += resJsonMin['snippet']

    chat = chat_model.start_chat(
        message_history=messages,
        context=context
        #examples=[
            #InputOutputTextPair(
                #input_text="How many moons does Mars have?",
                #output_text="The planet Mars has two moons, Phobos and Deimos.",
            #),
        #],
    )

    response = chat.send_message(
        question, **parameters
    )
    return(response.text)

def palm_summaraiz_conversation(question, conversation_name):
    messages_his = chat_history_user_text(conversation_name)
    model = TextGenerationModel.from_pretrained("text-bison@001")
    parameters = {
        "max_output_tokens": 32,
        "temperature": 0,
        "top_p": 0.8,
        "top_k": 40
    }
    
    #context = "סכם לי את השיחה הבאה בצורה הכי קצרה שתוכל, תגיד לי את הפעולה שהלוקח רוצה לעשות ותתייחס  למשפט האחרון שלו, השתמש רק במילים שמופיעות בשיחה, דוגמא לתשובה שתענה לי:  בקשה להחזר מס\n" + messages_his + "\n" + "user:" + question
    #context = "אני רוצה לקבל מונחי חיפוש מתוך השיחה הבאה לצורך חיפוש תשובת , ותתייחס למשפט האחרון שלו, השתמש רק במילים שמופיעות בשיחה, דוגמא לתשובה שתענה לי:  בקשה להחזר מס\n" + messages_his + "\n" + question
    context =  """סכם לי את 
user last question 
בצורה הכי קצרה שתוכל
לצורך חיפוש תשובות באינטרנט, השתמש רק במילים שמופיעות בשיחה 
כלול את כל חלקי השאלה 

user questions: 
user: מאיזה גיל ניתן לקבל רשיון נהיגה
revised query: רשיון נהיגה מאיזה גיל

user questions: 
user: מתי יגיע אלי רשיון הנהיגה
revised query:  רשיון נהיגה זמן הגעה

user questions: 
user: למשך כמה זמן התוקף של רישיון רכב
revised query:  רשיון רכב  כמה זמן תקף


user last question:{}
revised query: """.format(question)

    print("messages_his")
    print(messages_his) 
    print("context")
    print(context) 
    response = model.predict(
        context, **parameters
    )
    print('new summary')
    print(response)
    return(response.text)

def palm_pre_processing2(question, conversation_name):
    messages_his = chat_history(conversation_name)
    model = TextGenerationModel.from_pretrained("text-bison@001")
    parameters = {
        "temperature": 0.2,  # Temperature controls the degree of randomness in token selection.
        "max_output_tokens": 32,  # Token limit determines the maximum amount of text output.
        "top_p": 0.5,  # Tokens are selected from most probable to least until the sum of their probabilities equals the top_p value.
        "top_k": 40,  # A top_k of 1 means the selected token is the most probable among all tokens.
    }
    context =  """
.תנסח שאלה קצרה בעד 10 מילים מהשיחה המצורפת בין משתמש לבוט, תסכם את ההודעות של המשתמש לשאלה ספציפית קצרה 
אם יש שאלות שונות של המשתמש בטקסט תחזיר את השאלה האחרונה שהוא רשם 

user questions: user: היי
user: איזה מקצועות לומדים בכיתה ב
user: ואיזה לומדים בכיתה ג
revised query: אילו מקצועות לומדים בכיתה ג

user questions: user:  היכן אני בודק את הוותק שלי כמורה
user: האם אני זכאי לקרן השתלמות בשנת שבתון 
revised query: קרן השתלמות למורה בשנת שבתון 

user questions: user: מיומנויות למידה
revised query: מיומניות למידה למורה בכיתה

user questions: user:  אני מורה במטולה כבר 3 שנים האם אני זכאי להטבות
user: מה גובה ההטבות שאני זכאי אליהם
revised query: האם אני זכאי להטבות כמורה במטולה

user questions: {}
user last question: {}
revised query:
""".format(messages_his, question)
    print("contex is: ", context)
    response = model.predict(
        context, **parameters
    )
    return(response.text)

@app.route("/", methods=["GET"])

def hello_world():
    """Example Hello World route."""
    name = os.environ.get("NAME", "World")
    return f"Hello {name}!"


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))